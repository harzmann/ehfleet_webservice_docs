# EHFleet Webservice

ASP.NET-ASMX-Webservice für EHFleet Mobile- und Integrationsclients. Der Dienst stellt Funktionen für Fuhrpark, Werkstatt, Lieferanten, Mitarbeiter, Fahrzeuge, Unfälle, Abfahrtskontrolle, Führerscheinkontrolle und Werkstattartikel bereit und nutzt die Geschäftslogik aus `ehfleet_classlibrary`.

## Repository-Aufbau

- `ehfleet_webservice.sln` - Visual-Studio-Solution.
- `ehfleet_webservice/` - ASP.NET-Webanwendung für .NET Framework 4.8.
- `ehfleet_webservice/*.asmx.vb` - Webservice-Endpunkte.
- `scripts/Install-EHFleetWebservice.ps1` - Installationsskript für IIS und Web Deploy.
- `scripts/New-EHFleetWebserviceInstallPackage.ps1` - erstellt ein installierbares Kundenpaket mit Installer und Prüfsumme.
- `scripts/Publish-EHFleetWebserviceDocs.ps1` - aktualisiert das öffentliche MkDocs-Dokumentationsrepo.
- `.github/workflows/deploy.yml` - GitHub-Actions-Workflow für Build, Paket, Deployment und Dokumentation.

## Voraussetzungen für den Build

- Windows-Buildsystem.
- Visual Studio 2022 Build Tools oder Visual Studio mit Web-Build-Tools.
- .NET Framework 4.8 Developer Pack.
- .NET SDK 8.0 für die Schwesterbibliothek.
- NuGet CLI oder Visual-Studio-Restore.
- Web Deploy / MSDeploy für Paketierung und Deployment.

Der Webservice referenziert die Klassenbibliothek als Schwesterrepository:

```text
source/repos/
  ehfleet_webservice4/
  ehfleet_classlibrary/
```

Die Projektreferenz zeigt aus `ehfleet_webservice/ehfleet_webservice.vbproj` auf `..\..\ehfleet_classlibrary\ehfleet_classlibrary.vbproj`.

## Konfiguration

Die Datenbankverbindung wird zur Laufzeit aus `EHFleetConnectionString` in `ehfleet_webservice/web.config` gelesen.

Die versionierte `web.config` enthält nur einen Platzhalter. Die kundenspezifische oder produktive Verbindungszeichenfolge wird bei Installation oder Deployment gesetzt. Eine Vorlage liegt in `ehfleet_webservice/web.config.template`.

Beispiel für SQL-Authentifizierung:

```text
Provider=SQLOLEDB.1;Persist Security Info=False;User ID=ehfleet;Password=<passwort>;Initial Catalog=EHFleet;Data Source=<server>\<instanz>
```

## Lokaler Build

Vom Repository-Stamm aus:

```powershell
nuget restore .\ehfleet_webservice.sln
msbuild .\ehfleet_webservice.sln /p:Configuration=Release /p:Platform="Any CPU"
```

Web-Deploy-Paket erzeugen:

```powershell
msbuild .\ehfleet_webservice\ehfleet_webservice.vbproj `
  /p:Configuration=Release `
  /p:Platform="Any CPU" `
  /p:DeployOnBuild=true `
  /p:WebPublishMethod=Package `
  /p:PackageAsSingleFile=true `
  /p:PackageLocation="$pwd\artifacts\ehfleet_webservice.zip" `
  /p:DeployIisAppPath="Default Web Site/ehfleet_webservice"
```

Installierbares Kundenpaket erstellen:

```powershell
.\scripts\New-EHFleetWebserviceInstallPackage.ps1 `
  -WebDeployPackagePath ".\artifacts\ehfleet_webservice.zip" `
  -OutputDirectory ".\artifacts\customer"
```

Das Paket enthält das Web-Deploy-ZIP, das IIS-Installationsskript, eine Kurzinstallationsanleitung und eine SHA256-Prüfsumme.

## Lokales Debugging

Zur Laufzeit prüft der Webservice zuerst die Umgebungsvariable `EHFLEET_CONNECTION_STRING`. Ist sie leer, wird `EHFleetConnectionString` aus `web.config` verwendet.

Für lokales Visual-Studio-Debugging kann `EHFLEET_CONNECTION_STRING` in `ehfleet_webservice/ehfleet_webservice.vbproj.user` oder als Windows-Umgebungsvariable gesetzt werden. Debug-Builds lesen außerdem `LocalDebuggerEnvironment` aus der lokalen `.vbproj.user`, damit Local-IIS-Debugging eine Testdatenbank verwenden kann, ohne `web.config` zu ändern.

`.vbproj.user` darf keine echten Zugangsdaten enthalten und wird aus Web-Deploy-Paketen ausgeschlossen.

## GitHub-Actions-Deployment

Der Workflow läuft bei Push auf `master` und kann manuell gestartet werden. Er baut auf dem Entwicklungsrunner ein Web-Deploy-Paket, erzeugt daraus ein installierbares Kundenpaket, veröffentlicht Paket und Anleitung im öffentlichen MkDocs-Repository `harzmann/ehfleet_webservice_docs` und installiert anschließend den Webservice per MSDeploy auf dem Ziel-IIS.

Empfohlene Einrichtung des Entwicklungsrunners:

1. Self-hosted GitHub-Actions-Runner auf dem Entwicklungssystem installieren.
2. Runner mit `ehfleet-development` labeln.
3. Visual Studio Build Tools, .NET Framework 4.8 Developer Pack, .NET SDK 8.0, IIS Management Tools und Web Deploy installieren.
4. Repository-Secrets setzen:
   - `EHFLEET_REPO_TOKEN` - PAT mit Lesezugriff auf `harzmann/ehfleet_classlibrary`; als Fallback auch Schreibzugriff auf `harzmann/ehfleet_webservice_docs`.
   - `EHFLEET_DOCS_REPO_TOKEN` - optionaler PAT mit Schreibzugriff auf `harzmann/ehfleet_webservice_docs`.
   - `EHFLEET_CONNECTION_STRING` - produktive `EHFleetConnectionString`.
   - `MSDEPLOY_USER_NAME` - Windows-Administrator oder Deployment-Benutzer für `192.168.100.124`.
   - `MSDEPLOY_PASSWORD` - Passwort dieses Deployment-Benutzers.
5. Optionale Repository-Variablen:
   - `MSDEPLOY_TARGET_HOST` - Standardwert `192.168.100.124`.
   - `MSDEPLOY_TARGET_PACKAGE` - Standardwert `C:\Temp\ehfleet_webservice.zip`.
   - `MSDEPLOY_TARGET_EXE` - Standardwert `C:\Program Files\IIS\Microsoft Web Deploy V3\msdeploy.exe`.
   - `IIS_APP_PATH` - Standardwert `Default Web Site/ehfleet_webservice`.

Der Zielserver benötigt IIS, Web-Deploy-Kommandozeilenwerkzeuge, SMB-Admin-Share-Zugriff und Remoteverwaltung für geplante Tasks vom Entwicklungsrunner aus.

Der Workflow führt Smoke-Tests gegen diese URLs aus:

- `http://192.168.100.124:8080/ehfleet_webservice/WorkshopItems.asmx`
- `http://ehfleet.dyndns.org:8080/ehfleet_webservice/WorkshopItems.asmx`

Die öffentliche URL darf fehlschlagen, ohne das Deployment zu stoppen; die lokale URL ist verpflichtend.

## Öffentliche Dokumentation

Bei jedem erfolgreichen Build im Deployment-Workflow wird `harzmann/ehfleet_webservice_docs` aktualisiert. Das Doku-Repo enthält:

- Startseite mit aktueller Version, Commit und Prüfsumme.
- Downloadseite für das installierbare Webservice-Paket.
- Installationsanleitung für IIS.
- Änderungsprotokoll aus diesem Repository.
- GitHub-Pages-Workflow für MkDocs.

Die öffentliche Seite ist für GitHub Pages unter dieser Adresse vorgesehen:

```text
https://harzmann.github.io/ehfleet_webservice_docs/
```

## Kundeninstallation

Das Installationspaket herunterladen, entpacken und das Skript in einer erhöhten PowerShell starten:

```powershell
.\Install-EHFleetWebservice.ps1 `
  -SiteName "Default Web Site" `
  -AppName "ehfleet_webservice" `
  -AppPoolName "ehfleet_webservice" `
  -Port 8080 `
  -PhysicalPath "C:\inetpub\wwwroot\ehfleet_webservice" `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SqlServer ".\SQL2019" `
  -Database "EHFleet" `
  -SqlUser "ehfleet" `
  -SqlPassword "<passwort>"
```

Für Windows-Authentifizierung:

```powershell
.\Install-EHFleetWebservice.ps1 `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SqlServer ".\SQL2019" `
  -Database "EHFleet" `
  -UseWindowsAuth
```

Das Skript prüft IIS, ASP.NET 4.x, IIS-Verwaltungsdienst und Web Deploy. Fehlende Windows-Features werden nach Möglichkeit installiert; Web Deploy wird bei vorhandenem WinGet automatisch nachinstalliert.
