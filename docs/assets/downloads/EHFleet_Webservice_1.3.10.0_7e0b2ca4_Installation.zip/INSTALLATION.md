﻿# EHFleet Webservice Installation

Version: 1.3.10.0
Commit: 7e0b2ca4aaa753fb12e0d4dafb0af8dff4211a56
Paket erstellt: 2026-06-17T10:13:53Z

## Inhalt

- `ehfleet_webservice.zip` - Web-Deploy-Paket für IIS.
- `Install-EHFleetWebservice.ps1` - Installationsskript für IIS, App-Pool, Web Deploy und Datenbankverbindung.
- `README.md` - technische Projektübersicht.
- `CHANGELOG.md` - Änderungsprotokoll.

## Schnellstart

PowerShell als Administrator starten, Paket entpacken und aus dem entpackten Ordner ausführen:

```powershell
.\Install-EHFleetWebservice.ps1 `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SqlServer ".\SQL2019" `
  -Database "EHFleet" `
  -SqlUser "ehfleet" `
  -SqlPassword "<passwort>"
```

Für Windows-Authentifizierung:

```powershell
.\Install-EHFleetWebservice.ps1 `
  -PackagePath ".\ehfleet_webservice.zip" `
  -SqlServer ".\SQL2019" `
  -Database "EHFleet" `
  -UseWindowsAuth
```

Weitere Hinweise stehen in der öffentlichen Installationsanleitung.
